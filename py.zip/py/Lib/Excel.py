# coding: utf-8

import openpyxl

# テーブル読み込み
def ExcelSheet_GetTable( ws, y, x, h, w ):
	
	lst2dTbl = [];
	
	for iy in range(h):
	
		lstTbl = [];
		
		for ix in range(w):
			
			val = ws.cell(iy+y,ix+x).value;
			
			lstTbl.append( val );
						
		lst2dTbl.append( lstTbl );
	
	return lst2dTbl

# テーブル書き込み
def ExcelSheet_SetTable( ws, y, x, lst2dTbl ):
	
	h = len( lst2dTbl );
	
	for iy in range(h):
		
		lstTbl = lst2dTbl[iy];
		w = len( lstTbl );
		
		for ix in range(w):
		
			ws.cell(iy+y,ix+x).value = lstTbl[ix];
		

# 検索
def ExcelSheet_Search( ws, y, x, h, w, CmpData ):

	for iy in range(h):
			
		for ix in range(w):
			
			val = ws.cell(iy+y,ix+x).value;

			if( val == CmpData ):
				return iy+y,ix+x;


	return None,None;



