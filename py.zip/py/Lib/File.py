# coding: utf-8
import csv
import Lib.Common
import Lib.String
import Lib.Map
import os
import re
import shutil

s_FileEncoding = "utf-8";

# テキストエンコーダ設定
def SetTextEncoding( FileEncoding ):
	s_FileEncoding = FileEncoding;
	

# テキスト読み込み
def TextLoad( FileName ):

	ret = None;

	try:
		fp = open( FileName, "r", encoding = s_FileEncoding );

		ret = fp.read();
		
		fp.close();
	except:
		pass;
			
	return ret;
	
	
# テキスト書き込み
def TextSave( FileName, Text ):

	fp = open( FileName, "w", encoding = s_FileEncoding );

	fp.write( Text );
	
	fp.close();
	
	
# バイナリ読み込み
def BinLoad( FileName ):

	ret = None;

	try:
		fp = open( FileName, "rb" );

		ret = fp.read();
		
		fp.close();
	except:
		pass;
			
	return ret;
	
	
# バイナリ書き込み
def BinSave( FileName, Dat ):

	fp = open( FileName, "wb" );

	fp.write( Dat );
	
	fp.close();
	
	
	
# CSV読み込み
def CsvLoad( FileName ):

	try:
		hCsv = open( FileName, "r", encoding="ms932" );
		
		f = csv.reader( hCsv,delimiter=",", doublequote=True, lineterminator="\r\n", quotechar='"', skipinitialspace=True );

		tbl = {};
		y = 0;
		
		for row in f:
		
			cell = list(row);
			
			w = len( cell );
			
			for x in range(w):
				tbl[y,x] = cell[x];
						
			y = y + 1;		

		hCsv.close();

		return tbl;
	except:
		return None;

# CSV書き込み
def CsvSave( FileName, tbl ):

	h, w = Lib.Common.Tuple2dGetMaxNum(tbl);

	h += 1;
	w += 1;

	hCsv = open( FileName, "w", encoding="ms932" );

	writer = csv.writer(hCsv, lineterminator='\n');
	
	for y in range(h):
	
		buf = [""]*w;
	
		for x in range(w):
			try:
				buf[x] = tbl[y,x];
			except:
				buf[x] = "";

		
		writer.writerow(buf);
			
	hCsv.close();
	
# Configファイル読み込み
def ConfigLoad( FileName ):

	Text = TextLoad( FileName );
	
	if( Text == None ):
		return None;
	
	mapConfig = Lib.String.AnalysisConfig( Text );
	
	
	return mapConfig;

# 拡張子取得
def GetExt( FileName ):
	
	splitFile = os.path.splitext(FileName);
	Ext = splitFile[1];
	
	
	Ext = Ext.replace( ".", "" );

	return Ext;

# 拡張子判定
def IsExt( FileName, lstExt ):
	
	if( lstExt == None ):
		return True;
	
	Ext = GetExt(FileName);
	
	for tmpExt in lstExt:
	
		if( Ext == tmpExt ):
			return True;
	
	return False;

# ディレクトリのファイル抽出
def GetSearchFileCore( lstFile, InputDir, lstExt ):
	
	lstFileTmp = os.listdir(InputDir);

	for FileName in lstFileTmp:
	
		tmpFile = InputDir + "/" + FileName;
	
		if( os.path.isdir( tmpFile ) == True ):

			lstFile = GetSearchFileCore( lstFile, tmpFile, lstExt );
			
		elif( Lib.File.IsExt(tmpFile, lstExt) == True ):
			lstFile.append( tmpFile );
	
	return lstFile;

# ディレクトリのファイル抽出
def GetSearchFile( InputDir, lstExt ):
	
	lstFile = [];
	
	lstFile = GetSearchFileCore( lstFile, InputDir, lstExt );
	
	patDir = re.compile("^"+InputDir+"/");
	
	for i in range( len( lstFile ) ):
		lstFile[i] = re.sub( patDir, "", lstFile[i] );
		
	
	return lstFile;

# ファイルコピー
def Copy( OutputFileName, InputFileName ):

	DirName = os.path.dirname( OutputFileName );
	
	os.makedirs( DirName, exist_ok = True )
	
	shutil.copy2( InputFileName, OutputFileName )
	
# ファイルコピー
def CopyList( OutputDir, InputDir, lstFile ):

	for FileName in lstFile:
	
		InputFileName = "{0}/{1}".format( InputDir, FileName );
		OutputFileName = "{0}/{1}".format( OutputDir, FileName );
	
		Copy( OutputFileName, InputFileName );


