# coding: utf-8

import re
import Lib.Map

s_patDecimal = re.compile("^[+-]?[0-9]+$");
s_patHex = re.compile("^0[xX][0-9a-fA-F]+$");
s_patFloat = re.compile("^[+-]?[0-9]+\.[0-9]+([eE][+-]?[0-9]+)?$");

s_patHexPrefix = re.compile("^0[xX]");
s_patComment = re.compile("[ 　\t]*#.*");
s_patEq = re.compile(" *?= *");
s_patConfig = re.compile(".+?@.+");

# スペースを削除
def CutSpace( Text ):

	tmp = Text.replace( "\t", " " );
	tmp = tmp.replace( "　", " " );
	tmp = re.sub( " +", " ", tmp );
	tmp = re.sub( "^ ", "", tmp );
	tmp = re.sub( " $", "", tmp );
	tmp = tmp.replace( " \n", "\n" );
	tmp = tmp.replace( "\n ", "\n" );
	
	return tmp;

# コンフィグ解析
def AnalysisConfig( Text ):

	lstLine = GetLine( Text );
	
	lstLine = LineDelEmpty( lstLine );
	
	#print( lstLine );

	#LinePrint( lstLine );
	
	mapConfig = Lib.Map.CMap();
	
	for Line in lstLine:
		
		Line = re.sub( s_patComment, "", Line );
		Line = re.sub( s_patEq, "<@>", Line );
		Line = Line.replace( "\"", "" );
		Line = Line.replace( ";", "" );
		
		if( re.match( s_patConfig, Line ) != None ):
		
			el = Line.split("<@>");
			mapConfig.Set( el[0], el[1] );

	mapConfig.SetAllAutoType();

	return mapConfig;




# 16進数判定
def IsHex( Text ):
	return re.match( s_patHex, Text ) != None;


# 10進数判定
def IsDecimal( Text ):
	return re.match( s_patDecimal, Text ) != None;
	
# 浮動小数点判定
def IsFloat( Text ):
	return re.match( s_patFloat, Text ) != None;


# 整数判定
def IsInt( Text ):
	
	if( IsDecimal( Text ) ):
		return True;
		
	if( IsHex( Text ) ):
		return True;

	return False;

# 文字列判定
def IsString( Text ):
	
	if( IsInt( Text ) ):
		return False;
		
	if( IsFloat( Text ) ):
		return False;

	return True;

# 整数取得
def GetInt( Text ):

	if( IsDecimal( Text ) ):
		return int( Text );
		
	if( IsHex( Text ) ):
		tmp = re.sub( s_patHexPrefix, "", Text );
		return int( tmp, 16 );
		
	if( IsFloat( Text ) ):
		return int(float( Text ));
	
	return None;

# 浮動小数取得
def GetFloat( Text ):

	if( IsDecimal( Text ) ):
		return float(int( Text ));
		
	if( IsHex( Text ) ):
		tmp = re.sub( s_patHexPrefix, "", Text );
		return float(int( tmp, 16 ));
		
	if( IsFloat( Text ) ):
		return float( Text );
	
	return None;

# 数値取得(整数、浮動小数自動判定)
def GetNum( Text ):

	if( IsDecimal( Text ) ):
		return int( Text );
		
	if( IsHex( Text ) ):
		tmp = re.sub( s_patHexPrefix, "", Text );
		return int( tmp, 16 );
		
	if( IsFloat( Text ) ):
		return float( Text );
	
	return None;

# 型 自動判定
def GetAutoType( Text ):

	val = GetNum( Text );
	
	if( val != None ):
		return val;

	return Text;

# 行取得
def GetLine( Text ):

	lstLine = Text.split("\n");
	
	return lstLine;

# 行表示
def LinePrint( lstLine ):

	sz = len( lstLine );

	i = 0;
	while( i < sz ):
		print( i, "\t",lstLine[i] );
		i += 1;

# 空行削除
def LineDelEmpty( lstLine ):

	return [item for item in lstLine if item != ""] 


# 単位を考慮した整数を取得する
# 終端が k, K, m, M, g, G 
def GetNumUnit( Text ):

	
	try:
		sz = len( Text );
		Unit = Text[sz-1];
		
		UnitNum = 1;
		if( ( Unit == "k" ) or ( Unit == "K" ) ):
			UnitNum = 1024;
		elif( ( Unit == "m" ) or ( Unit == "M" ) ):
			UnitNum = 1024*1024;
		elif( ( Unit == "g" ) or ( Unit == "G" ) ):
			UnitNum = 1024*1024*1024;
		
		tmp = Text;
		if( not (UnitNum == 1) ):
			tmp = Text[0:sz-1];
			
		return GetNum( tmp ) * UnitNum;

	except:
		return None;
	
# 位置情報よりの文字列を抽出する
def AbstructString( Text, lstPos ):

	lstText = [];
	for pos in lstPos:
		
		lstText.append( Text[pos[0]:pos[1]] );

	return lstText;

# 指定文字列の位置情報を抽出する
def SearchPos( Text, Label ):

	lenLabel = len( Label );

	lstPos = [];
	pos = 0;

	while( 1 ):
	
		pos = Text.find( Label, pos );
		if( pos == -1 ):
			break;
			
		posStart = pos;
		pos += lenLabel;
		posEnd = pos;
		
		lstPos.append((posStart, posEnd));

	return lstPos;
	
# 指定文字列の位置情報を抽出する(正規表現版)
def SearchPos_Re( Text, Label ):

	lstPos = [];
	pos = 0;
	
	rLabel = re.compile(Label);
	
	while( 1 ):
		
		m = rLabel.search(Text,pos);
		if( m == None ):
			break;
		pos = m.end();
		
		lstPos.append((m.start(), pos));
	
	
	return lstPos;
	



# 指定文字列の間の位置情報を抽出する
def AbstructPos( Text, StartLabel, EndLabel ):

	lenStart = len( StartLabel );
	lenEnd = len( EndLabel );

	lstPos = [];
	pos = 0;

	while( 1 ):
	
		pos = Text.find( StartLabel, pos );
		if( pos == -1 ):
			break;
		pos += lenStart;
		
		posStart = pos;
		
		pos = Text.find( EndLabel, pos );
		if( pos == -1 ):
			break;
			
		posEnd = pos;
		pos += lenEnd;
		
		lstPos.append((posStart, posEnd));

	return lstPos;
	

# 指定文字列の間の位置情報を抽出する(正規表現版)
def AbstructPos_Re( Text, StartLabel, EndLabel ):

	lstPos = [];
	pos = 0;
	
	rStart = re.compile(StartLabel);
	rEnd = re.compile(EndLabel);
	
	while( 1 ):
		
		m = rStart.search(Text,pos);
		if( m == None ):
			break;
		pos = m.end();
		
		posStart = pos;
		
		m = rEnd.search(Text,pos);
		if( m == None ):
			break;
		posEnd = m.start();
		
		pos = m.end();
		
		lstPos.append((posStart, posEnd));
	
	
	return lstPos;
	


