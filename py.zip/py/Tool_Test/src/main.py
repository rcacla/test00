# coding: utf-8

import os
import sys

sys.path.append(os.getcwd()+"/..");

import openpyxl
import csv


import Lib.Common
import Lib.File
import Lib.String
import Lib.Map
import Lib.Excel

import pyautogui
import pyperclip
import re
	
import subprocess
import time
import pyautogui

#import win32gui
#import win32con
#import win32process

#import winxpgui


def main( argv ):


	if( len( argv ) != 2 ):
		print( "param: [config param]\n" );
		return 0;
	
	mapConfig = Lib.File.ConfigLoad( argv[1] );

	InputDir = mapConfig.Get( "InputDir" );
	OutputDir = mapConfig.Get( "OutputDir" );
	

	lstExt = [];
	lstExt.append( "cpp" );
	lstExt.append( "h" );
	#lstExt.append( "obj" );

	lstFile = Lib.File.GetSearchFile( InputDir, lstExt)
	#lstFile = Lib.File.GetSearchFile( InputDir, None)
	
	lstTarget = [];
	lstTarget.append( "/app/CreateCsv/" );
	lstTarget.append( "app/CreateVottInput/" );
	
	
	#for FileName in lstFile:
	
		#FileName = Lib.File.GetBaseFileName( FileName );
		#FileName = Lib.File.GetFileName( FileName );
		#FileName = Lib.File.GetDirName( FileName );
		
		#print( FileName );
	
	
	
	#Lib.File.Copy( "out/zzz/ああああ/aaa.bin", "in/proj/app/backup/myfunc.cpp" );
	
	#Lib.File.CopyList( OutputDir, InputDir, lstFile );
	

	#print( lstFile );
	
	
	#os.makedirs( "out/zzz/あああ/hhh.txt", exist_ok = True )
	
	#shutil.copy2('in/data.bin', 'out/zzz/aaa.bin')
	
	
	return 1
    





if __name__ == '__main__':
	sys.exit(main(sys.argv));


