# coding: utf-8

import Lib.String

# Mapクラス
class CMap:

	# コンストラクタ
	def __init__(self):
		
		self.Clear();
		
	# 設定
	def Set( self, Key, Val ):
	
		self.__map.update( {Key: Val} );

	# 取得
	def Get( self, Key ):
		
		ret = None;
		try:
			ret = self.__map[Key];
		except:
			pass;
	
		return ret;

	# キーリスト取得
	def GetKey(self):
	
		sz = self.GetSize();
		
		key = [0]*sz;
		i = 0;
		for el in self.__map:
			key[i] = el;
			i += 1;
		
		return key
		
	# マップ数取得
	def GetSize( self ):
		return len(self.__map);
	
	# 表示
	def Print(self):
	
		for el in self.__map:
			print( el, " : ", self.__map[el] );
		
	# 全ての値の型を自動判定
	def SetAllAutoType(self):
		for el in self.__map:
			self.__map[el] = Lib.String.GetAutoType( self.__map[el] );
			
	# クリア
	def Clear(self):
		
		self.__map = {};
		

# Mapクラス ValにIndexを使用し、自動更新する
class CMapIndex:

	# コンストラクタ
	def __init__(self):
		
		self.Clear();
		
	# 設定
	def Set( self, Key ):
	
		ret = self.Get( Key );
		
		if( ret == None ):
			ret = self.GetSize();
			self.__map.Set( Key, ret );		
		
		return ret;
		
	# 取得
	def Get( self, Key ):
		return self.__map.Get( Key );
		
	# キーリスト取得
	def GetKey(self):
		return self.__map.GetKey();
		
	# マップ数取得
	def GetSize( self ):
		return self.__map.GetSize();
		
		
	# 表示
	def Print(self):
	
		self.__map.Print();
	
	# クリア
	def Clear(self):
		
		self.__map = CMap();




