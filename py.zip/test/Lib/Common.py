# coding: utf-8


# 2次元コレクションのタプルの最大値を取得
def Tuple2dGetMaxNum( tbl ):

	x0 = -1;
	x1 = -1;

	for el in tbl:

		if( x0 < el[0] ):
			x0 = el[0];
		
		if( x1 < el[1] ):
			x1 = el[1];
		
	return x0, x1;
	
# 設定されていないテーブルを埋める
def Tuple2dFill( tbl, val ):

	h, w = Tuple2dGetMaxNum( tbl );

	h += 1;
	w += 1;

	for y in range(h):	
		for x in range(w):
			index = (y, x);
			try:
				dummy = tbl[index];
			except:
				tbl[index] = val;

	
	
# テーブルに加算処理を行う
def TableAdd( tbl, index, val ):

	try:
		tbl[index] += val;
	except:
		tbl[index] = val;
	
# 2次元リストを表示
def lst2dPrint( lst2dTbl ):

	for lstTbl in lst2dTbl:
		print( lstTbl );



