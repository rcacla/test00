# coding: utf-8

import os
import sys

sys.path.append(os.getcwd()+"/..");

import Lib.Common
import Lib.File
import Lib.String
import Lib.Map


def main( argv ):

	if( len( argv ) != 2 ):
		print( "param: [config param]\n" );
		return 0;
	
	mapConfig = Lib.File.ConfigLoad( argv[1] );

	InputDir0 = mapConfig.Get( "InputDir0" );
	InputDir1 = mapConfig.Get( "InputDir1" );
	OutputDir = mapConfig.Get( "OutputDir" );

	lst2dDiff = Lib.File.IsMatchDir( InputDir0, InputDir1, None );

	lstFile0 = [];
	lstFile1 = [];

	for lstDiff in lst2dDiff:

		FileName = lstDiff[0];
		No = lstDiff[1];
		
		if( No == 1 ):
			lstFile0.append( FileName );
			lstFile1.append( FileName );
		elif( No == 2 ):
			lstFile0.append( FileName );
		elif( No == 3 ):
			lstFile1.append( FileName );
			
	OutputFile = OutputDir + "/list0.txt";
	Lib.File.ListTextSave( OutputFile, lstFile0 );

	OutputFile = OutputDir + "/list1.txt";
	Lib.File.ListTextSave( OutputFile, lstFile1 );
	
	Lib.File.CopyList( OutputDir+"/dir0", InputDir0, lstFile0 );
	Lib.File.CopyList( OutputDir+"/dir1", InputDir1, lstFile1 );
	

	return 1
    
    

if __name__ == '__main__':
	sys.exit(main(sys.argv));


