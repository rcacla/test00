# coding: utf-8

import os
import sys

sys.path.append(os.getcwd()+"/..");

import openpyxl
import csv


import Lib.Common
import Lib.File
import Lib.String
import Lib.Map
import Lib.Excel

import pyautogui
import pyperclip
import re
	
import subprocess
import time
import pyautogui



def main( argv ):


	if( len( argv ) != 2 ):
		print( "param: [config param]\n" );
		return 0;
	
	mapConfig = Lib.File.ConfigLoad( argv[1] );

	InputDir = mapConfig.Get( "InputDir" );
	OutputDir = mapConfig.Get( "OutputDir" );

	Name0 = InputDir + "/0";
	Name1 = InputDir + "/1";
	
	lst2dDiff = Lib.File.IsMatchDir( Name0, Name1, None );

	print( lst2dDiff );

	return 1
    
    

if __name__ == '__main__':
	sys.exit(main(sys.argv));


